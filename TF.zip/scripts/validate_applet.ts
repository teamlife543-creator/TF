import { productsModel } from "../src/models/productsModel";
import { combosModel } from "../src/models/combosModel";
import { CartModel } from "../src/models/cartModel";
import { OrderController } from "../src/controllers/orderController";

interface TestReport {
  name: string;
  passed: boolean;
  details: string;
}

const reports: TestReport[] = [];

function assert(condition: boolean, name: string, details: string) {
  reports.push({
    name,
    passed: Boolean(condition),
    details,
  });
  if (!condition) {
    console.error(`❌ FAIL: ${name} -> ${details}`);
  } else {
    console.log(`✅ PASS: ${name}`);
  }
}

async function runValidation() {
  console.log("=== INICIANDO VALIDACIÓN AUTOMATIZADA TEAM LIFE ===");

  // 1. Catálogo de Productos Oficiales (5 productos)
  const products = productsModel.getAll();
  assert(
    products.length === 5,
    "Catálogo de 5 Productos Oficiales",
    `Total productos: ${products.length} (esperado: 5)`
  );

  const colageno = productsModel.getById("tl-colageno");
  assert(
    Boolean(colageno && colageno.normalPrice === 342 && colageno.memberPrice === 205),
    "Producto Colágeno Marino precios oficiales",
    `Normal: ${colageno?.normalPrice} Bs, Socio: ${colageno?.memberPrice} Bs`
  );

  const coffee = productsModel.getById("tl-coffeelife");
  assert(
    Boolean(coffee && coffee.normalPrice === 359 && coffee.memberPrice === 215),
    "Producto Coffee Life con Cordyceps precios oficiales",
    `Normal: ${coffee?.normalPrice} Bs, Socio: ${coffee?.memberPrice} Bs`
  );

  // 2. Combos Oficiales (3 combos + Kit de Bienvenida)
  const combos = combosModel.getAll();
  assert(
    combos.length === 4,
    "Combos y Kit de Bienvenida Oficiales",
    `Total combos: ${combos.length} (3 Combos Empresariales + Kit de Bienvenida)`
  );

  const kit = combosModel.getById("kit-de-bienvenida");
  assert(
    Boolean(kit && kit.comboPrice === 250),
    "Kit de Bienvenida precio oficial 250 Bs",
    `Precio kit: ${kit?.comboPrice} Bs`
  );

  const combo1 = combosModel.getById("combo-1-empresarial");
  assert(
    Boolean(combo1 && combo1.comboPrice === 1360 && combo1.profitPercentage === 60),
    "Combo 1 Empresarial 1360 Bs con 60% ganancia",
    `Precio: ${combo1?.comboPrice} Bs, Ganancia: ${combo1?.profitPercentage}%`
  );

  const combo3 = combosModel.getById("combo-3-empresarial");
  assert(
    Boolean(combo3 && combo3.comboPrice === 4650 && combo3.profitPercentage === 87),
    "Combo 3 Empresarial 4650 Bs con 87% ganancia",
    `Precio: ${combo3?.comboPrice} Bs, Ganancia: ${combo3?.profitPercentage}%`
  );

  // 3. Carrito - Aislamiento, Deduplicación, Sumas e Imágenes
  const testCart = new CartModel();
  testCart.clearCart();

  // Test 3a: Agregar producto una sola vez incrementa cantidad sin duplicar fila
  if (colageno) {
    testCart.addProduct(colageno, 1);
    assert(
      testCart.getItems().length === 1 && testCart.getTotalCount() === 1 && testCart.getTotalPrice() === 342,
      "Carrito: Agregar 1 Colágeno (342 Bs)",
      `Filas: ${testCart.getItems().length}, Cantidad: ${testCart.getTotalCount()}, Total: ${testCart.getTotalPrice()}`
    );

    // Segundo click al mismo producto
    testCart.addProduct(colageno, 1);
    assert(
      testCart.getItems().length === 1 && testCart.getTotalCount() === 2 && testCart.getTotalPrice() === 684,
      "Carrito: Deduplicación correcta (1 fila, cantidad 2, total 684 Bs)",
      `Filas: ${testCart.getItems().length}, Cantidad: ${testCart.getTotalCount()}, Total: ${testCart.getTotalPrice()}`
    );
  }

  // Test 3b: Agregar combo con mismo ID o distinto ID
  if (kit) {
    testCart.addCombo(kit, 1);
    assert(
      testCart.getItems().length === 2 && testCart.getTotalCount() === 3 && testCart.getTotalPrice() === 684 + 250,
      "Carrito: Agregar Kit de Bienvenida (250 Bs) junto a productos",
      `Filas: ${testCart.getItems().length}, Cantidad: ${testCart.getTotalCount()}, Total: ${testCart.getTotalPrice()} Bs`
    );
  }

  // Test 3c: Incrementar y decrementar cantidad
  if (colageno) {
    testCart.updateQuantity(colageno.id, false, 1); // colágeno sube a 3
    assert(
      testCart.getTotalCount() === 4 && testCart.getTotalPrice() === 342 * 3 + 250,
      "Carrito: Botón (+) incrementa cantidad a 3",
      `Total items: ${testCart.getTotalCount()}, Total: ${testCart.getTotalPrice()}`
    );

    testCart.updateQuantity(colageno.id, false, -1); // colágeno baja a 2
    assert(
      testCart.getTotalCount() === 3 && testCart.getTotalPrice() === 342 * 2 + 250,
      "Carrito: Botón (-) decrementa cantidad a 2",
      `Total items: ${testCart.getTotalCount()}, Total: ${testCart.getTotalPrice()}`
    );
  }

  // Test 3d: Eliminar ítem
  if (kit) {
    testCart.removeItem(kit.id, true);
    assert(
      testCart.getItems().length === 1 && testCart.getTotalCount() === 2 && testCart.getTotalPrice() === 684,
      "Carrito: Botón eliminar quita el Kit correctamente",
      `Filas restantes: ${testCart.getItems().length}, Total: ${testCart.getTotalPrice()}`
    );
  }

  // 4. OrderController - Generación de Enlace WhatsApp y Datos de Vendedor
  const orderCtrl = new OrderController();
  const testOrder = await orderCtrl.submitOrder({
    clientName: "Carlos Meneses",
    clientPhone: "78812345",
    countryCode: "591",
    countryName: "Bolivia",
    department: "Cochabamba",
    items: testCart.getItems(),
    total: testCart.getTotalPrice(),
    vendedorWhatsapp: "59178877543",
    referrerId: "DIST-LPZ-014",
  });

  assert(
    testOrder.success && testOrder.waUrl.includes("https://wa.me/59178877543"),
    "Generación de enlace WhatsApp hacia número oficial/distribuidor",
    `URL: ${testOrder.waUrl.substring(0, 60)}...`
  );

  const decodedWaText = decodeURIComponent(testOrder.waUrl);
  assert(
    decodedWaText.includes("Carlos Meneses") &&
      decodedWaText.includes("+591 78812345") &&
      decodedWaText.includes("Cochabamba") &&
      decodedWaText.includes("DIST-LPZ-014") &&
      decodedWaText.includes("684"),
    "Mensaje WhatsApp contiene cliente, teléfono, depto, ref y total",
    `Fragmento: ${decodedWaText.substring(0, 150)}...`
  );

  // 5. AuthController & Superadmin Rules
  const { authController } = await import("../src/controllers/authController");
  const phoneFormatted = authController.cleanPhone("72019482", "591");
  assert(
    phoneFormatted === "59172019482",
    "Limpieza y formateo de celular para WhatsApp internacional",
    `Resultado: ${phoneFormatted} (esperado: 59172019482)`
  );

  const phoneWithCode = authController.cleanPhone("+591 72019482", "591");
  assert(
    phoneWithCode === "59172019482",
    "Normalización de prefijo +591 con espacios y símbolos",
    `Resultado: ${phoneWithCode}`
  );

  // 6. AIController - Respuestas grounded sin alucinaciones
  const { aiController } = await import("../src/controllers/aiController");
  const founderResp = aiController.generateResponse("Quiénes son los fundadores de Team Life?");
  assert(
    founderResp.reply.includes("Julian Rodriguez") && founderResp.reply.includes("Mery Ruiz"),
    "IA: Información oficial de fundadores (Julian Rodriguez & Mery Ruiz)",
    `Contiene fundadores: ${founderResp.reply.includes("Julian Rodriguez")}`
  );

  const legalResp = aiController.generateResponse("Tienen NIT y registro SENASAG?");
  assert(
    legalResp.reply.includes("572065026") && legalResp.reply.includes("166/2025"),
    "IA: Datos de respaldo legal (NIT 572065026 y SENASAG 166/2025)",
    `Contiene NIT y SENASAG: ${legalResp.reply.includes("572065026")}`
  );

  const coffeeResp = aiController.generateResponse("Para qué sirve el café con cordyceps y cuánto cuesta?");
  assert(
    coffeeResp.reply.includes("Coffee Life") &&
      coffeeResp.reply.includes("359") &&
      coffeeResp.reply.includes("215"),
    "IA: Precios oficiales de Coffee Life con Ganoderma y Cordyceps (359 / 215 Bs)",
    `Respuesta contiene precios exactos`
  );

  const comboResp = aiController.generateResponse("Cuáles son los combos empresariales?");
  assert(
    comboResp.reply.includes("1.360") &&
      comboResp.reply.includes("2.500") &&
      comboResp.reply.includes("4.650"),
    "IA: Precios de los 3 Combos Empresariales (1.360, 2.500, 4.650 Bs)",
    `Respuesta contiene combos empresariales`
  );

  // 7. Modificación de Producto y Preservación de ID
  const originalColageno = productsModel.getById("tl-colageno")!;
  const updateSuccess = productsModel.updateProduct("tl-colageno", {
    name: "Colágeno Marino Hidrolizado (Edición Especial)",
    promoPrice: 310,
    status: "publicado",
  });
  const modifiedColageno = productsModel.getById("tl-colageno");
  assert(
    updateSuccess &&
      modifiedColageno?.id === "tl-colageno" &&
      modifiedColageno?.promoPrice === 310 &&
      modifiedColageno?.name.includes("Edición Especial"),
    "Modificación de Producto: Preservación de ID y actualización de campos",
    `ID: ${modifiedColageno?.id}, Promo: ${modifiedColageno?.promoPrice}`
  );
  // Revert for consistency
  productsModel.updateProduct("tl-colageno", {
    name: originalColageno.name,
    promoPrice: undefined,
  });

  // 8. Modificación de Combo y Componentes
  const originalCombo1 = combosModel.getById("combo-1-empresarial")!;
  const comboUpdateSuccess = combosModel.updateCombo("combo-1-empresarial", {
    comboPrice: 1400,
    promoPrice: 1350,
    includedProducts: [
      "2x Colágeno Marino Hidrolizado",
      "2x Inmune Plus Multi-Defensas",
      "2x Fibernat Fibra Soluble",
      "1x Muestra Extra Fibernat",
    ],
  });
  const modifiedCombo1 = combosModel.getById("combo-1-empresarial");
  assert(
    comboUpdateSuccess &&
      modifiedCombo1?.id === "combo-1-empresarial" &&
      modifiedCombo1?.comboPrice === 1400 &&
      modifiedCombo1?.includedProducts?.length === 4,
    "Modificación de Combo: Preservación de ID y adición de componentes",
    `ID: ${modifiedCombo1?.id}, Precio: ${modifiedCombo1?.comboPrice}, Componentes: ${modifiedCombo1?.includedProducts?.length}`
  );
  // Revert combo
  combosModel.updateCombo("combo-1-empresarial", {
    comboPrice: originalCombo1.comboPrice,
    promoPrice: undefined,
    includedProducts: originalCombo1.includedProducts,
  });

  // 9. Validación de URLs y Protección SSRF
  const { isSafePublicUrl } = await import("../src/utils/urlExtractor");
  const localCheck = isSafePublicUrl("http://localhost:8080/exploit");
  assert(
    !localCheck.valid && localCheck.reason?.includes("SSRF"),
    "Seguridad de Enlaces: Bloqueo de localhost (SSRF)",
    `Bloqueado: ${!localCheck.valid}`
  );

  const privateIpCheck = isSafePublicUrl("http://192.168.1.100/admin");
  assert(
    !privateIpCheck.valid && privateIpCheck.reason?.includes("SSRF"),
    "Seguridad de Enlaces: Bloqueo de IP privada 192.168.x (SSRF)",
    `Bloqueado: ${!privateIpCheck.valid}`
  );

  const cloudMetaCheck = isSafePublicUrl("http://169.254.169.254/latest/meta-data");
  assert(
    !cloudMetaCheck.valid,
    "Seguridad de Enlaces: Bloqueo de IP de metadatos de nube 169.254.169.254",
    `Bloqueado: ${!cloudMetaCheck.valid}`
  );

  const validWebCheck = isSafePublicUrl("https://teamlife.com.bo/productos/colageno");
  assert(
    validWebCheck.valid && Boolean(validWebCheck.sanitizedUrl),
    "Seguridad de Enlaces: Aceptación de URL HTTPS pública segura",
    `Válido: ${validWebCheck.sanitizedUrl}`
  );

  // 10. Modificación de Celular de Usuario y Regeneración de Enlaces
  const updatedPhone = authController.cleanPhone("78945612", "591");
  const regeneratedWaLink = `https://wa.me/${updatedPhone}`;
  assert(
    regeneratedWaLink === "https://wa.me/59178945612",
    "Regeneración de Enlace WhatsApp tras modificación de número",
    `Enlace: ${regeneratedWaLink}`
  );

  // 11. Preservación de Pedidos Históricos ante Cambios de Catálogo
  assert(
    testOrder.success && testOrder.waUrl.includes("684"),
    "Integridad Histórica: Pedido registrado conserva su total histórico independientemente de cambios futuros",
    `Total pedido histórico inmutable: Bs 684`
  );


  console.log("\n=== RESUMEN DE PRUEBAS AUTOMATIZADAS ===");
  const allPassed = reports.every((r) => r.passed);
  console.log(
    `Total pruebas: ${reports.length} | Aprobadas: ${
      reports.filter((r) => r.passed).length
    } | Fallidas: ${reports.filter((r) => !r.passed).length}`
  );
  if (!allPassed) {
    process.exit(1);
  }
  process.exit(0);
}

runValidation().catch((e) => {
  console.error("Error en validación:", e);
  process.exit(1);
});

