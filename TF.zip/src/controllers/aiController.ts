import { productsModel } from "../models/productsModel";
import { combosModel } from "../models/combosModel";
import { Product, Combo, AiKnowledgeItem } from "../models/types";
import { db, firebase } from "../models/firebaseModel";
import { auditController } from "./auditController";

export interface AIResponse {
  reply: string;
  recommendedProduct?: Product;
  recommendedCombo?: Combo;
  matchedKnowledge?: AiKnowledgeItem;
}

export class AIController {
  private isSpeaking: boolean = false;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private cachedKnowledge: AiKnowledgeItem[] = [];
  private lastKnowledgeFetch: number = 0;

  // Retrieve published knowledge items from Firestore
  public async getPublishedKnowledge(forceRefresh: boolean = false): Promise<AiKnowledgeItem[]> {
    const now = Date.now();
    if (!forceRefresh && this.cachedKnowledge.length > 0 && now - this.lastKnowledgeFetch < 60000) {
      return this.cachedKnowledge;
    }

    try {
      const snap = await db.collection("ai_knowledge").where("status", "==", "publicado").get();
      const list: AiKnowledgeItem[] = [];
      snap.forEach((doc) => {
        const d = doc.data();
        list.push({
          id: doc.id,
          title: d.title || "",
          category: d.category || "general",
          content: d.content || "",
          status: "publicado",
          tags: d.tags || [],
          createdAt: d.createdAt ? d.createdAt.toDate?.() || d.createdAt : new Date(),
          updatedAt: d.updatedAt ? d.updatedAt.toDate?.() || d.updatedAt : new Date(),
          author: d.author || "Superadministrador",
        });
      });
      this.cachedKnowledge = list;
      this.lastKnowledgeFetch = now;
      return list;
    } catch (e) {
      console.warn("Nota al leer ai_knowledge de Firestore:", e);
      return this.cachedKnowledge;
    }
  }

  // Superadmin CRUD for knowledge items
  public async getAllKnowledgeItems(): Promise<AiKnowledgeItem[]> {
    try {
      const snap = await db.collection("ai_knowledge").orderBy("updatedAt", "desc").limit(50).get();
      const list: AiKnowledgeItem[] = [];
      snap.forEach((doc) => {
        const d = doc.data();
        list.push({
          id: doc.id,
          title: d.title || "",
          category: d.category || "general",
          content: d.content || "",
          status: d.status || "publicado",
          tags: d.tags || [],
          createdAt: d.createdAt ? d.createdAt.toDate?.() || d.createdAt : new Date(),
          updatedAt: d.updatedAt ? d.updatedAt.toDate?.() || d.updatedAt : new Date(),
          author: d.author || "Superadministrador",
        });
      });
      return list;
    } catch (e) {
      console.warn("Error leyendo base de conocimiento completa:", e);
      return [
        {
          id: "k-default-1",
          title: "Legalidad, NIT y Registro Sanitario SENASAG",
          category: "legalidad",
          content:
            "TEAM LIFE COMPANY S.R.L. cuenta con NIT 572065026 (Régimen General, emite Factura Oficial en cada compra), Registro Sanitario SENASAG No. 166/2025 emitido en Santa Cruz el 17 de Febrero de 2025 y Matrícula SEPREC vigente.",
          status: "publicado",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: "k-default-2",
          title: "Plan de Carrera y Afiliación Básica (Kit Bs 250)",
          category: "negocio",
          content:
            "El Kit de Bienvenida oficial cuesta Bs 250 e incluye muestras bioactivas, bolígrafo ejecutivo y otorga 40% de descuento vitalicio en toda la línea. Por cada nuevo afiliado directo el socio recibe Bs 150 en mano.",
          status: "publicado",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: "k-default-3",
          title: "Política de Despachos y Envíos a los 9 Departamentos",
          category: "protocolos",
          content:
            "Todos los pedidos confirmados por WhatsApp se despachan en menos de 24 horas hábiles hacia La Paz, Santa Cruz, Cochabamba, Oruro, Potosí, Chuquisaca, Tarija, Beni y Pando con guía oficial de encomienda.",
          status: "publicado",
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];
    }
  }

  public async saveKnowledgeItem(item: {
    id?: string;
    title: string;
    category: AiKnowledgeItem["category"];
    content: string;
    status: "publicado" | "borrador" | "desactivado";
  }): Promise<string> {
    const data = {
      title: item.title.trim(),
      category: item.category,
      content: item.content.trim(),
      status: item.status,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
    };

    if (item.id) {
      await db.collection("ai_knowledge").doc(item.id).set(data, { merge: true });
      await auditController.logEvent(
        "Modificación de artículo de conocimiento IA",
        "ia",
        `Artículo "${item.title}" actualizado con estado "${item.status}".`
      );
      this.lastKnowledgeFetch = 0; // Invalidate cache
      return item.id;
    } else {
      const docRef = await db.collection("ai_knowledge").add({
        ...data,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        author: "Superadministrador",
      });
      await auditController.logEvent(
        "Nuevo artículo de conocimiento IA",
        "ia",
        `Artículo "${item.title}" creado en categoría ${item.category} (${item.status}).`
      );
      this.lastKnowledgeFetch = 0;
      return docRef.id;
    }
  }

  public async deleteKnowledgeItem(id: string, title?: string): Promise<void> {
    await db.collection("ai_knowledge").doc(id).delete();
    await auditController.logEvent(
      "Eliminación de artículo de conocimiento IA",
      "ia",
      `Artículo ID: ${id} ("${title || "Sin título"}") eliminado del centro de conocimiento.`
    );
    this.lastKnowledgeFetch = 0;
  }

  // Generate grounded response
  public generateResponse(prompt: string): AIResponse {
    const p = prompt.toLowerCase().trim();
    const products = productsModel.getAll();
    const combos = combosModel.getAll();

    const getP = (id: string) => products.find((x) => x.id === id);
    const getC = (id: string) => combos.find((x) => x.id === id);

    let reply = "";
    let matchedProd: Product | undefined;
    let matchedCombo: Combo | undefined;
    let matchedKnowledge: AiKnowledgeItem | undefined;

    // 1. Check dynamic published knowledge items first
    if (this.cachedKnowledge.length > 0) {
      const match = this.cachedKnowledge.find((k) => {
        const titleMatch = k.title.toLowerCase().split(/\s+/).some((w) => w.length > 3 && p.includes(w));
        const words = k.content.toLowerCase().split(/\s+/).filter((w) => w.length > 4);
        const contentOverlap = words.filter((w) => p.includes(w)).length;
        return titleMatch || contentOverlap >= 2;
      });

      if (match) {
        matchedKnowledge = match;
      }
    }

    // 2. Strict domain matching with official Team Life knowledge
    if (
      p.includes("fundador") ||
      p.includes("julian") ||
      p.includes("mery") ||
      p.includes("creador") ||
      p.includes("ceo") ||
      p.includes("dueño")
    ) {
      reply =
        "TEAM LIFE COMPANY S.R.L. fue fundada por Julian Rodriguez y Mery Ruiz.\n\n• Experiencia Médica: Más de 20 años en medicina convencional, alternativas medicinales y nutrición celular.\n• Liderazgo: Más de 10 años en Network Marketing. Líderes visionarios con la convicción de que 'JUNTOS TODO ES POSIBLE'.\n• Legalidad: NIT 572065026 (Régimen General, emite factura fiscal), Registro Sanitario SENASAG No. 166/2025 y Registro SEPREC.";
      matchedCombo = getC("kit-de-bienvenida");
    } else if (
      p.includes("legal") ||
      p.includes("nit") ||
      p.includes("senasag") ||
      p.includes("seprec") ||
      p.includes("factura")
    ) {
      reply =
        "TEAM LIFE cuenta con respaldo legal pleno en Bolivia:\n\n1. SEPREC: Matrícula de Comercio vigente como TEAM LIFE COMPANY S.R.L.\n2. Impuestos Nacionales: NIT 572065026 (Régimen General, emite Factura Oficial en cada compra).\n3. SENASAG: Certificado de Registro Sanitario No. 166/2025 emitido en Santa Cruz.\n\nTodos los productos y comisiones son 100% legales y transparentes.";
      matchedCombo = getC("kit-de-bienvenida");
    } else if (
      p.includes("cordyceps") ||
      p.includes("coffee") ||
      p.includes("cafe") ||
      p.includes("café") ||
      p.includes("ganoderma") ||
      p.includes("energia") ||
      p.includes("energía")
    ) {
      reply =
        "Coffee Life Premium (Ganoderma + Cordyceps Sinensis):\n\n• Presentación: Caja de 30 sachets de 4.5g.\n• Ingredientes: Café Orgánico de Altura, Cordyceps Sinensis, Ganoderma Lucidum y Colágeno Marino Hidrolizado.\n• Para qué sirve: Aumenta el oxígeno celular y capacidad pulmonar (apoyo para asma y bronquitis), mejora la función renal y salud sexual, neuroprotección (Parkinson y Alzheimer) y energía celular limpia sin taquicardia ni reflujo.\n\n• Precios: Regular Bs 359 · Socio 40% OFF: Bs 215.";
      matchedProd = getP("tl-coffeelife");
    } else if (
      p.includes("colageno") ||
      p.includes("colágeno") ||
      p.includes("articulac") ||
      p.includes("rodilla") ||
      p.includes("cartilago") ||
      p.includes("piel")
    ) {
      reply =
        "Colágeno Marino Hidrolizado (Fórmula Reforzada):\n\n• Presentación: Caja de 30 sobres de 10g (300g peso neto).\n• Ingredientes: Colágeno Marino Hidrolizado, Ácido Hialurónico, Coenzima Q10, Mix de Vitaminas y Minerales, Pulpa de Açaí Liofilizado.\n• Para qué sirve: Regenera articulaciones, cartílagos y ligamentos; tonifica la piel y combate flacidez; fortalece cabello, uñas y el humor vítreo del ojo.\n\n• Precios: Regular Bs 342 · Socio 40% OFF: Bs 205.";
      matchedProd = getP("tl-colageno");
    } else if (
      p.includes("inmune") ||
      p.includes("defens") ||
      p.includes("gripe") ||
      p.includes("resfri") ||
      p.includes("noni") ||
      p.includes("guanabana") ||
      p.includes("camu")
    ) {
      reply =
        "Inmune Plus Multi-Defensas Activas:\n\n• Presentación: Caja de 30 sobres de 7g (210g peso neto).\n• Ingredientes: Noni, Guanábana, Jengibre, Cúrcuma, Camu Camu, Flor de Jamaica, Aloe Vera y Vitamina C quelada.\n• Para qué sirve: Eleva el sistema inmune, antiviral y antibacteriano de choque para gripe o tos, controla hipertensión, depura el hígado y acción antioxidante preventiva.\n\n• Precios: Regular Bs 409 · Socio 40% OFF: Bs 245.";
      matchedProd = getP("tl-inmune");
    } else if (
      p.includes("fibernat") ||
      p.includes("digest") ||
      p.includes("colon") ||
      p.includes("estreñ") ||
      p.includes("pitahaya") ||
      p.includes("moringa") ||
      p.includes("vientre")
    ) {
      reply =
        "Fibernat Fibra Soluble & Detox Intestinal:\n\n• Presentación: Sobres de 6g c/u (Cont. Neto: 50g).\n• Ingredientes: Psyllium orgánico, Moringa, Vitamina C, Pitahaya, Citrato de Magnesio y Manzana Verde Liofilizada.\n• Para qué sirve: Normaliza el tránsito intestinal y alivia estreñimiento sin cólicos; regenera flora del colon; logra un vientre plano en 48 hrs y regula glucosa y colesterol.\n\n• Precios: Regular Bs 159 · Socio 40% OFF: Bs 95.";
      matchedProd = getP("tl-fibernat");
    } else if (
      p.includes("chocokids") ||
      p.includes("niño") ||
      p.includes("infantil") ||
      p.includes("crecimiento") ||
      p.includes("cerebro") ||
      p.includes("tdah")
    ) {
      reply =
        "Choco Kids+ Nutrition (Sin Azúcar Refinada):\n\n• Presentación: Caja de sobres de 8g.\n• Ingredientes: Proteína Aislada de Soja, Avena, Cacao Alcalino, Vitaminas/Minerales (Calcio, Hierro, Zinc), Omega 3, L-Arginina, Psyllium, Probióticos (yogurt) y Harina de Linaza.\n• Para qué sirve: Estimula el crecimiento en estatura (L-Arginina/Zinc), desarrollo cerebral y visión (Omega 3), disminuye ansiedad escolar y apoya en TDAH; fortalece defensas.\n\n• Precios: Regular Bs 409 · Socio 40% OFF: Bs 245.";
      matchedProd = getP("tl-chocokids");
    } else if (
      p.includes("combo 1") ||
      p.includes("combo 2") ||
      p.includes("combo 3") ||
      p.includes("empresarial") ||
      p.includes("1360") ||
      p.includes("2500") ||
      p.includes("4650")
    ) {
      reply =
        "Combos Empresariales Oficiales Team Life:\n\n1. Combo 1 (6 Prod.): 2 Fibernat + 2 Inmune + 2 Colágeno = Bs 1.360 (Bs 1.125 Comisionable) · 60% Ganancia.\n2. Combo 2 (12 Prod.): 4 Fibernat + 3 Inmune + 4 Colágeno + 1 Coffee Life = Bs 2.500 (Bs 2.057 Comisionable) · 73% Ganancia.\n3. Combo 3 (25 Prod.): 10 Fibernat + 6 Inmune + 7 Colágeno + 2 Coffee Life = Bs 4.650 (Bs 3.806 Comisionable) · 87% Ganancia y activa Bono Impulso Plus de Bs 1.500.";
      matchedCombo = getC("combo-3-empresarial") || getC("combo-1-empresarial");
    } else if (
      p.includes("afiliar") ||
      p.includes("40%") ||
      p.includes("250") ||
      p.includes("membresia") ||
      p.includes("kit")
    ) {
      reply =
        "La Afiliación Básica cuesta Bs 250 (Kit de Bienvenida oficial):\n\n• Incluye caja con muestras de producto (Fibernat, Inmune Plus, Colágeno), bolígrafo ejecutivo grabado, manual y catálogo.\n• Beneficio: 40% de descuento vitalicio en toda la línea sin compras mínimas mensuales obligatorias.\n• Patrocinios directos exprés: Ganas Bs 150 en mano por cada nuevo consumidor afiliado.";
      matchedCombo = getC("kit-de-bienvenida");
    } else if (matchedKnowledge) {
      reply = `📚 *Base de Conocimiento Team Life - ${matchedKnowledge.title}*:\n\n${matchedKnowledge.content}`;
    } else {
      reply =
        "En TEAM LIFE COMPANY S.R.L. disponemos de 5 formulaciones bioactivas oficiales (Colágeno Bs 342, Coffee Life Bs 359 con Cordyceps, Inmune Plus Bs 409, Fibernat Bs 159, Chocokids Bs 409), el Kit de Afiliación de Bs 250 (40% OFF) y Combos Empresariales con hasta el 87% de ganancias. Despachos garantizados a los 9 departamentos de Bolivia.";
      matchedProd = getP("tl-colageno");
    }

    return { reply, recommendedProduct: matchedProd, recommendedCombo: matchedCombo, matchedKnowledge };
  }

  public speak(text: string, onStart?: () => void, onEnd?: () => void) {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    this.stopSpeaking();

    const clean = text
      .replace(/[*_#`~]/g, "")
      .replace(/https?:\/\/\S+/g, "")
      .replace(/Bs\s?(\d+)/gi, "$1 bolivianos")
      .trim();

    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = "es-ES";
    utterance.rate = 0.98;
    utterance.pitch = 1.02;

    const voices = window.speechSynthesis.getVoices();
    const spanishVoice =
      voices.find(
        (v) =>
          v.lang.startsWith("es") &&
          (v.name.includes("Natural") ||
            v.name.includes("Google") ||
            v.name.includes("Sabina") ||
            v.name.includes("Helena") ||
            v.name.includes("Paulina"))
      ) || voices.find((v) => v.lang.startsWith("es"));

    if (spanishVoice) {
      utterance.voice = spanishVoice;
    }

    utterance.onstart = () => {
      this.isSpeaking = true;
      if (onStart) onStart();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      if (onEnd) onEnd();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      if (onEnd) onEnd();
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  public stopSpeaking() {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
  }
}

export const aiController = new AIController();
